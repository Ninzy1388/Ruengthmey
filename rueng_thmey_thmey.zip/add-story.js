document.getElementById('storyForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const title = document.getElementById('title').value.trim();
    const content = document.getElementById('content').value.trim();

    if (title && content) {
        const story = { title, content };
        const stories = JSON.parse(localStorage.getItem('stories') || '[]');
        stories.push(story);
        localStorage.setItem('stories', JSON.stringify(stories));
        alert('✅ រឿងបានរក្សាទុក!');
        window.location.href = 'index.html';
    }
});
