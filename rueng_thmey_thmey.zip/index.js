document.addEventListener('DOMContentLoaded', function () {
    const stories = JSON.parse(localStorage.getItem('stories') || '[]');
    const list = document.getElementById('story-list');

    stories.reverse().forEach(story => {
        const div = document.createElement('div');
        div.className = 'story';
        div.innerHTML = `<h3>${story.title}</h3><p>${story.content}</p>`;
        list.appendChild(div);
    });
});
